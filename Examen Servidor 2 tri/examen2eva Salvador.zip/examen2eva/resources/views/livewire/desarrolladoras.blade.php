<div>
    <select>
        @foreach($desarroladoras as $desarroladora)
            <option>$desarroladora</option>
        @endforeach
    </select>

</div>
