<div>
    <select>
        @foreach ($distribuidoras as $distribuidora)
            <option>$distribuidora</option>
        @endforeach
    </select>

</div>
