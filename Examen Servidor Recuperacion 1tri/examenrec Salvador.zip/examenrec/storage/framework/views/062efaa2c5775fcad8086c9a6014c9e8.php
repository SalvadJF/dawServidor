<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Películas</title>
</head>
<body>
    <h1>Películas</h1>

    <ul>
        <li><a href="<?php echo e(route('libros.index')); ?>">Listado de libros</a></li>
        <li><a href="<?php echo e(route('libros.create')); ?>">Crear libro</a></li>
    </ul>
</body>
</html>
<?php /**PATH /home/sjimenez/Escritorio/Eservidor/Examen Servidor Recuperacion 1tri/examenrec/resources/views/principal.blade.php ENDPATH**/ ?>