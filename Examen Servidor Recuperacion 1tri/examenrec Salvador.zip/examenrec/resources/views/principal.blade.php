<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Películas</title>
</head>
<body>
    <h1>Películas</h1>

    <ul>
        <li><a href="{{ route('libros.index') }}">Listado de libros</a></li>
        <li><a href="{{ route('libros.create') }}">Crear libro</a></li>
    </ul>
</body>
</html>
